# 🔩 Kubernetes 核心组件详解

## 组件交互总览

```
                    ┌──────────────┐
                    │    User      │
                    │  (kubectl)   │
                    └──────┬───────┘
                           │ HTTPS
                           ▼
┌──────────────────────────────────────────────────────────────┐
│                     Control Plane                             │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │                    API Server                            │ │
│  │   ┌──────────┐  ┌───────────┐  ┌──────────────────┐    │ │
│  │   │ 认证      │  │  授权      │  │  准入控制         │    │ │
│  │   │ (AuthN)  │─>│  (AuthZ)  │─>│ (Admission)      │    │ │
│  │   └──────────┘  └───────────┘  └──────────────────┘    │ │
│  └─────────────────────────────────────────────────────────┘ │
│            │            │            │            │          │
│            ▼            ▼            ▼            ▼          │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌───────────┐ │
│  │    etcd    │ │ Scheduler  │ │ Controller │ │  Cloud    │ │
│  │            │ │            │ │  Manager   │ │ Controller│ │
│  └────────────┘ └────────────┘ └────────────┘ └───────────┘ │
└──────────────────────────────────────────────────────────────┘
                           │
           ┌───────────────┼───────────────┐
           │               │               │
           ▼               ▼               ▼
    ┌────────────┐  ┌────────────┐  ┌────────────┐
    │   Node 1   │  │   Node 2   │  │   Node 3   │
    │  ┌──────┐  │  │  ┌──────┐  │  │  ┌──────┐  │
    │  │kubelet│ │  │  │kubelet│ │  │  │kubelet│ │
    │  └──────┘  │  │  └──────┘  │  │  └──────┘  │
    │  ┌──────┐  │  │  ┌──────┐  │  │  ┌──────┐  │
    │  │proxy │  │  │  │proxy │  │  │  │proxy │  │
    │  └──────┘  │  │  └──────┘  │  │  └──────┘  │
    └────────────┘  └────────────┘  └────────────┘
```

## 1. API Server 深入详解

### 1.1 核心功能

API Server 是 Kubernetes 的"前门"，所有操作都必须经过它。

```
请求处理流程：
┌────────────────────────────────────────────────────────────────┐
│                        API Server                               │
│                                                                  │
│  ┌──────────┐    ┌──────────┐    ┌──────────────────────────┐ │
│  │   认证    │───>│   授权    │───>│       准入控制           │ │
│  │ (AuthN)  │    │ (AuthZ)  │    │  Mutating + Validating   │ │
│  └──────────┘    └──────────┘    └──────────────────────────┘ │
│       │              │                       │                  │
│       ▼              ▼                       ▼                  │
│   谁在请求？     是否有权限？         是否符合策略？              │
│   (身份验证)    (RBAC检查)         (修改/验证资源)              │
└────────────────────────────────────────────────────────────────┘
```

### 1.2 认证方式

```yaml
# 常见认证方式
认证方式:
  - X509 客户端证书     # 最常用，kubeconfig 默认方式
  - Bearer Token       # ServiceAccount 使用
  - Bootstrap Token    # 节点加入集群
  - OpenID Connect     # 集成企业认证
  - Webhook Token      # 外部认证服务
```

### 1.3 API 版本演进

```
API 版本成熟度：
alpha (v1alpha1) → beta (v1beta1) → stable (v1)
     │                  │                │
     ▼                  ▼                ▼
   实验性           即将稳定           生产可用
   可能移除         默认启用           长期支持
```

### 1.4 查看 API Server

```bash
# 查看 API Server 地址
kubectl cluster-info

# 直接访问 API（需要认证）
kubectl proxy &  # 启动代理
curl http://localhost:8001/api/v1/namespaces

# 查看 API Server 配置（如果能访问 master 节点）
cat /etc/kubernetes/manifests/kube-apiserver.yaml
```

## 2. etcd 深入详解

### 2.1 什么是 etcd？

etcd 是一个分布式键值数据库，Kubernetes 用它存储所有集群数据。

```
etcd 存储结构：
/registry
├── /pods
│   ├── /default/nginx-pod
│   └── /kube-system/coredns-xxx
├── /services
│   └── /default/kubernetes
├── /deployments
│   └── /default/nginx-deployment
├── /secrets
│   └── /default/my-secret
└── /configmaps
    └── /default/my-config
```

### 2.2 etcd 核心特性

| 特性 | 说明 |
|------|------|
| 强一致性 | 使用 Raft 协议保证数据一致 |
| 高可用 | 支持集群部署（建议 3/5/7 节点） |
| Watch 机制 | 支持监听数据变化 |
| MVCC | 多版本并发控制 |

### 2.3 etcd 操作示例（高级）

```bash
# 在 etcd 容器中执行（需要访问 master 节点）
# 列出所有 key
etcdctl get / --prefix --keys-only

# 查看某个资源
etcdctl get /registry/pods/default/nginx --print-value-only

# 查看集群成员
etcdctl member list

# 查看集群健康状态
etcdctl endpoint health
```

## 3. Scheduler 深入详解

### 3.1 调度流程

```
                     ┌──────────────────┐
                     │   待调度的 Pod    │
                     └────────┬─────────┘
                              │
                              ▼
              ┌───────────────────────────────┐
              │       预选（Predicates）        │
              │    过滤不满足条件的节点          │
              └───────────────┬───────────────┘
                              │
                              ▼
              ┌───────────────────────────────┐
              │       优选（Priorities）        │
              │    对剩余节点打分排序           │
              └───────────────┬───────────────┘
                              │
                              ▼
              ┌───────────────────────────────┐
              │          选择节点              │
              │    选择得分最高的节点           │
              └───────────────┬───────────────┘
                              │
                              ▼
              ┌───────────────────────────────┐
              │          绑定 Pod             │
              │    更新 Pod 的 nodeName        │
              └───────────────────────────────┘
```

### 3.2 预选（Filtering）策略

```yaml
常见预选策略:
  PodFitsResources:    # 节点资源是否满足 Pod 需求
  PodFitsHost:         # 节点名是否匹配 nodeName
  PodFitsHostPorts:    # 端口是否冲突
  PodMatchNodeSelector: # 是否匹配 nodeSelector
  NoDiskConflict:      # 存储卷是否冲突
  CheckNodeCondition:  # 节点是否处于 Ready 状态
  PodToleratesNodeTaints: # 是否容忍节点污点
```

### 3.3 优选（Scoring）策略

```yaml
常见优选策略:
  LeastRequestedPriority:  # 资源使用率最低优先
  BalancedResourceAllocation: # 资源均衡分配
  ImageLocalityPriority:   # 镜像已存在优先
  NodeAffinityPriority:    # 节点亲和性
  InterPodAffinityPriority: # Pod 亲和性
```

### 3.4 调度示例

```yaml
# pod-scheduling-example.yaml
apiVersion: v1
kind: Pod
metadata:
  name: scheduling-demo
spec:
  # 指定节点选择器
  nodeSelector:
    disktype: ssd
  
  # 资源请求（影响调度）
  containers:
  - name: nginx
    image: nginx
    resources:
      requests:
        cpu: "500m"
        memory: "256Mi"
      limits:
        cpu: "1"
        memory: "512Mi"
  
  # 容忍度
  tolerations:
  - key: "key1"
    operator: "Equal"
    value: "value1"
    effect: "NoSchedule"
```

## 4. Controller Manager 深入详解

### 4.1 控制器模式

Controller 的核心是**控制循环**（Control Loop）：

```
┌────────────────────────────────────────────────────────────┐
│                     Control Loop                            │
│                                                              │
│   ┌──────────┐     ┌──────────┐     ┌──────────────────┐  │
│   │ 观察当前  │────>│  对比差异  │────>│  执行调谐操作     │  │
│   │   状态    │     │          │     │  (Reconcile)     │  │
│   └──────────┘     └──────────┘     └──────────────────┘  │
│        ▲                                      │            │
│        │                                      │            │
│        └──────────────────────────────────────┘            │
│                                                              │
│              期望状态 vs 当前状态 → 采取行动                   │
└────────────────────────────────────────────────────────────┘
```

### 4.2 常见控制器详解

#### Deployment Controller

```
期望: 3 个副本
当前: 2 个 Pod 运行中

Deployment Controller 动作:
→ 发现差异：缺少 1 个副本
→ 创建新的 Pod
→ 持续监控直到达到期望状态
```

#### Node Controller

```
职责:
1. 监控节点健康状态
2. 节点失联后标记为 NotReady
3. 超时后驱逐节点上的 Pod

时间线:
0s:    节点失联
40s:   标记 Unknown
5m:    开始驱逐 Pod
```

#### ReplicaSet Controller

```
监听: ReplicaSet 资源变化
动作:
  - 副本不足 → 创建 Pod
  - 副本过多 → 删除 Pod
  - 更新标签选择器 → 调整 Pod
```

### 4.3 查看控制器状态

```bash
# 查看 controller-manager pod
kubectl get pod -n kube-system | grep controller-manager

# 查看日志
kubectl logs -n kube-system kube-controller-manager-<node-name>

# 查看控制器配置
kubectl describe pod -n kube-system kube-controller-manager-<node-name>
```

## 5. kubelet 深入详解

### 5.1 kubelet 职责

```
┌────────────────────────────────────────────────────────┐
│                       kubelet                          │
│                                                        │
│  ┌──────────────────────────────────────────────────┐ │
│  │               主要职责                            │ │
│  │                                                   │ │
│  │  1. 向 API Server 注册节点                        │ │
│  │  2. 监听 API Server 分配的 Pod                    │ │
│  │  3. 调用容器运行时创建/管理容器                    │ │
│  │  4. 执行健康检查                                  │ │
│  │  5. 上报节点和 Pod 状态                           │ │
│  │  6. 管理卷的挂载/卸载                             │ │
│  └──────────────────────────────────────────────────┘ │
│                                                        │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────┐   │
│  │   CRI    │  │   CNI    │  │      CSI         │   │
│  │ 容器运行时│  │ 网络插件  │  │    存储插件       │   │
│  └──────────┘  └──────────┘  └──────────────────┘   │
└────────────────────────────────────────────────────────┘
```

### 5.2 kubelet 与 CRI

```
                kubelet
                   │
                   │ gRPC
                   ▼
            ┌─────────────┐
            │     CRI     │ (Container Runtime Interface)
            └─────────────┘
                   │
        ┌──────────┼──────────┐
        ▼          ▼          ▼
   containerd    CRI-O    Docker+cri-dockerd
```

### 5.3 健康检查类型

```yaml
# Pod 健康检查示例
apiVersion: v1
kind: Pod
metadata:
  name: health-check-demo
spec:
  containers:
  - name: app
    image: nginx
    
    # 存活探针 - 检测容器是否存活
    livenessProbe:
      httpGet:
        path: /healthz
        port: 8080
      initialDelaySeconds: 10
      periodSeconds: 10
    
    # 就绪探针 - 检测容器是否准备好接收流量
    readinessProbe:
      httpGet:
        path: /ready
        port: 8080
      initialDelaySeconds: 5
      periodSeconds: 5
    
    # 启动探针 - 检测容器是否启动完成
    startupProbe:
      httpGet:
        path: /startup
        port: 8080
      failureThreshold: 30
      periodSeconds: 10
```

## 6. kube-proxy 深入详解

### 6.1 Service 实现原理

```
             Client
                │
                ▼
        ┌───────────────┐
        │   Service IP   │  10.96.0.100:80
        │   (虚拟 IP)     │
        └───────┬───────┘
                │
                ▼
        ┌───────────────┐
        │  kube-proxy   │  iptables/IPVS 规则
        └───────┬───────┘
                │
        ┌───────┴───────┐
        ▼               ▼
   ┌─────────┐    ┌─────────┐
   │  Pod A  │    │  Pod B  │
   │10.1.1.10│    │10.1.2.20│
   └─────────┘    └─────────┘
```

### 6.2 工作模式对比

| 模式 | 原理 | 性能 | 适用场景 |
|------|------|------|---------|
| iptables | 使用 iptables 规则转发 | 中等 | 默认模式 |
| IPVS | 使用 Linux IPVS 模块 | 高 | 大规模集群 |
| userspace | 用户空间代理 | 低 | 已弃用 |

### 6.3 iptables 模式示例

```bash
# 查看 kube-proxy 创建的 iptables 规则
sudo iptables -t nat -L -n | grep -i kubernetes

# 规则链示例
KUBE-SERVICES       # 入口链，匹配 Service ClusterIP
KUBE-SVC-XXX        # 单个 Service 的规则
KUBE-SEP-XXX        # 单个 Endpoint（Pod）的规则
```

## 7. 组件通信安全

### 7.1 证书体系

```
                     Root CA
                        │
        ┌───────────────┼───────────────┐
        ▼               ▼               ▼
   API Server CA    etcd CA       Front Proxy CA
        │               │               │
        ▼               ▼               ▼
  ┌─────────────┐ ┌─────────┐  ┌─────────────────┐
  │ API Server  │ │  etcd   │  │ Aggregation API │
  │ kubelet     │ │ Client  │  │    Server       │
  │ Controller  │ │ Peer    │  └─────────────────┘
  │ Scheduler   │ └─────────┘
  └─────────────┘
```

### 7.2 查看证书

```bash
# 查看 kubeconfig 中的证书
kubectl config view

# 查看证书详情（在 master 节点）
openssl x509 -in /etc/kubernetes/pki/apiserver.crt -text -noout

# 检查证书过期时间
kubeadm certs check-expiration
```

## 实践练习

### 练习 1：探索组件 Pod

```bash
# 查看所有系统组件
kubectl get pods -n kube-system -o wide

# 查看组件详情
kubectl describe pod -n kube-system kube-apiserver-<node>
kubectl describe pod -n kube-system etcd-<node>

# 查看组件日志
kubectl logs -n kube-system kube-scheduler-<node>
```

### 练习 2：监控调度过程

```bash
# 创建一个 Pod
kubectl run test-pod --image=nginx

# 查看调度事件
kubectl describe pod test-pod

# 查看调度器日志
kubectl logs -n kube-system kube-scheduler-<node> | grep test-pod
```

### 练习 3：理解控制器

```bash
# 创建 Deployment
kubectl create deployment nginx --image=nginx --replicas=3

# 观察 ReplicaSet
kubectl get rs -w

# 删除一个 Pod，观察自动恢复
kubectl delete pod <pod-name>
kubectl get pods -w
```

## 关键要点

1. **API Server 是中心**：所有组件都通过它通信
2. **etcd 是唯一数据源**：只有 API Server 可以直接访问
3. **控制器模式**：对比期望状态和当前状态，自动调谐
4. **声明式 API**：告诉 K8s 要什么，而不是怎么做
5. **松耦合设计**：组件可以独立升级和替换

## 下一步

- [核心概念与术语](./03-concepts.md) - 理解 K8s 的核心概念



