# 🚀 项目一：部署微服务应用

## 项目目标

学习如何部署一个完整的微服务应用，包括：
- 前端服务 (Frontend)
- 后端 API 服务 (Backend)
- 数据库 (MySQL)
- 缓存 (Redis)

## 架构图

```
                    Internet
                        │
                        ▼
                   ┌─────────┐
                   │ Ingress │
                   └────┬────┘
                        │
                        ▼
            ┌───────────────────────┐
            │    Frontend Service   │
            │      (Nginx + SPA)    │
            └───────────┬───────────┘
                        │
                        ▼
            ┌───────────────────────┐
            │    Backend Service    │
            │      (API Server)     │
            └───────────┬───────────┘
                   ┌────┴────┐
                   │         │
                   ▼         ▼
           ┌───────────┐ ┌───────────┐
           │   MySQL   │ │   Redis   │
           └───────────┘ └───────────┘
```

## 部署步骤

### 1. 创建命名空间

```bash
kubectl apply -f namespace.yaml
```

### 2. 部署 MySQL

```bash
kubectl apply -f mysql/
```

### 3. 部署 Redis

```bash
kubectl apply -f redis/
```

### 4. 部署 Backend

```bash
kubectl apply -f backend/
```

### 5. 部署 Frontend

```bash
kubectl apply -f frontend/
```

### 6. 配置 Ingress（可选）

```bash
kubectl apply -f ingress.yaml
```

## 验证部署

```bash
# 查看所有资源
kubectl get all -n microservice

# 检查 Pod 状态
kubectl get pods -n microservice

# 测试服务
kubectl port-forward svc/frontend -n microservice 8080:80
curl http://localhost:8080
```

## 清理

```bash
kubectl delete namespace microservice
```



